import { afterEach, beforeEach, describe, it, expect, vi } from 'vitest';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { loadCantoneseVoices, speak } from '../../frontend/src/genai/speech';

const plan = { mode: 'browser', language: 'zh-HK', selection: 'cantonese_male' } as const;
const english = { name: 'English male', lang: 'en-US' } as SpeechSynthesisVoice;
const female = { name: 'Sinji', lang: 'yue-HK' } as SpeechSynthesisVoice;
const male = { name: 'Cantonese male', lang: 'zh-HK' } as SpeechSynthesisVoice;
const mapSource = readFileSync('frontend/public/map-demo/map-demo.js', 'utf8');
const loaderSource = mapSource.slice(
  mapSource.indexOf('function loadCantoneseVoices('),
  mapSource.indexOf('function initializeNavigation()'),
);
function browserGlobals() {
  return { setTimeout, clearTimeout, setInterval, clearInterval, AbortController, DOMException };
}
function engine(initial: SpeechSynthesisVoice[] = []) {
  let voices = initial;
  const listeners = new Set<() => void>();
  const play = vi.fn((utterance) => {
    utterance.onstart?.();
    utterance.onend?.();
  });
  const synth = {
    getVoices: vi.fn(() => voices),
    cancel: vi.fn(),
    speak: play,
    addEventListener: vi.fn((_name: string, listener: () => void) => listeners.add(listener)),
    removeEventListener: vi.fn((_name: string, listener: () => void) => listeners.delete(listener)),
  };
  return {
    synth: synth as unknown as SpeechSynthesis,
    play,
    listeners,
    update(next: SpeechSynthesisVoice[], emit = true) {
      voices = next;
      if (emit) [...listeners].forEach((listener) => listener());
    },
  };
}
class Utterance {
  constructor(public text: string) {}
}
function mapSpeaker(synth: SpeechSynthesis) {
  const narrationStatus = { textContent: '' };
  let pagehide: (() => void) | undefined;
  const source = mapSource.slice(
    mapSource.indexOf(
      '  let pendingVoiceLoad;',
      mapSource.indexOf('function initializeNavigation()'),
    ),
    mapSource.indexOf(
      '  const workflowContext =',
      mapSource.indexOf('function initializeNavigation()'),
    ),
  );
  const run = vm.runInNewContext(`${loaderSource}\n${source}\nspeakInstruction;`, {
    ...browserGlobals(),
    narrationStatus,
    SpeechSynthesisUtterance: Utterance,
    window: {
      speechSynthesis: synth,
      SpeechSynthesisUtterance: Utterance,
      addEventListener(_name: string, listener: () => void) {
        pagehide = listener;
      },
    },
  }) as (instruction: { title: string; detail: string }) => Promise<void>;
  return { run, narrationStatus, hide: () => pagehide?.() };
}
beforeEach(() => vi.useFakeTimers());
afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

for (const variant of ['legacy', 'map-demo'] as const) {
  describe(`${variant}: Cantonese voice loading`, () => {
    const load = (synth: SpeechSynthesis, signal?: AbortSignal) => {
      const fn =
        variant === 'legacy'
          ? loadCantoneseVoices
          : (vm.runInNewContext(
              `${loaderSource}\nloadCantoneseVoices;`,
              browserGlobals(),
            ) as typeof loadCantoneseVoices);
      return fn(synth, signal);
    };
    it('waits for an initially empty list and removes all listeners/timers after loading', async () => {
      const e = engine();
      const pending = load(e.synth);
      await vi.advanceTimersByTimeAsync(320);
      e.update([english, female]);
      expect(await pending).toEqual([female]);
      expect(e.listeners.size).toBe(0);
      expect(vi.getTimerCount()).toBe(0);
    });
    it('keeps waiting through English-only voiceschanged events', async () => {
      const e = engine([english]);
      let settled = false;
      const pending = load(e.synth).then((v) => {
        settled = true;
        return v;
      });
      e.update([english]);
      await vi.advanceTimersByTimeAsync(1800);
      expect(settled).toBe(false);
      e.update([english, female]);
      expect(await pending).toEqual([female]);
    });
    it('finds Cantonese through polling when voiceschanged is missing', async () => {
      const e = engine([english]);
      const pending = load(e.synth);
      e.update([english, female], false);
      await vi.advanceTimersByTimeAsync(100);
      expect(await pending).toEqual([female]);
      expect(vi.getTimerCount()).toBe(0);
    });
    it('bounds waiting when Cantonese never becomes available', async () => {
      const e = engine([english]);
      const pending = load(e.synth);
      await vi.advanceTimersByTimeAsync(5000);
      expect(await pending).toEqual([]);
      expect(e.listeners.size).toBe(0);
      expect(vi.getTimerCount()).toBe(0);
    });
    it('aborts a superseded load and removes timers/listeners', async () => {
      const e = engine();
      const controller = new AbortController();
      const pending = load(e.synth, controller.signal);
      const assertion = expect(pending).rejects.toMatchObject({ name: 'AbortError' });
      controller.abort();
      await assertion;
      expect(e.listeners.size).toBe(0);
      expect(vi.getTimerCount()).toBe(0);
    });
    it('accepts Yue and underscore tags without accepting Mandarin', async () => {
      const e = engine([
        { name: 'Mandarin', lang: 'zh-CN' },
        { name: 'Hong Kong', lang: 'zh_HK' },
        female,
      ] as SpeechSynthesisVoice[]);
      expect((await load(e.synth)).map((v) => v.lang)).toEqual(['zh_HK', 'yue-HK']);
      expect(vi.getTimerCount()).toBe(0);
    });
  });
}

it('text-only mode does not need a speech engine', async () => {
  await expect(speak('文字', { ...plan, selection: 'text_only' })).resolves.toBeUndefined();
});
it('preserves the preferred Cantonese male voice', async () => {
  const e = engine([english, female, male]);
  vi.stubGlobal('window', { speechSynthesis: e.synth });
  vi.stubGlobal('SpeechSynthesisUtterance', Utterance);
  await speak('請慢慢行', plan);
  expect(e.play.mock.calls[0][0].voice).toBe(male);
});
it('uses the selected voice language when the browser reports yue-HK', async () => {
  const e = engine([female]);
  vi.stubGlobal('window', { speechSynthesis: e.synth });
  vi.stubGlobal('SpeechSynthesisUtterance', Utterance);
  await speak('請慢慢行', plan);
  expect(e.play.mock.calls[0][0].lang).toBe('yue-HK');
});
it('legacy: a newer request replaces pending speech before voices load', async () => {
  const e = engine();
  vi.stubGlobal('window', { speechSynthesis: e.synth });
  vi.stubGlobal('SpeechSynthesisUtterance', Utterance);
  const first = speak('舊步驟', plan),
    second = speak('新步驟', plan);
  e.update([female]);
  await Promise.all([first, second]);
  expect(e.play.mock.calls.map(([u]) => u.text)).toEqual(['新步驟']);
  expect(vi.getTimerCount()).toBe(0);
});
it('does not use an English fallback when Cantonese remains unavailable', async () => {
  const e = engine([english]);
  vi.stubGlobal('window', { speechSynthesis: e.synth });
  vi.stubGlobal('SpeechSynthesisUtterance', Utterance);
  const pending = expect(speak('請慢慢行', plan)).rejects.toThrow('等候後瀏覽器仍未提供粵語語音');
  await vi.advanceTimersByTimeAsync(5000);
  await pending;
  expect(e.play).not.toHaveBeenCalled();
});
it('map-demo: first click waits for voices then speaks without another click', async () => {
  const e = engine();
  const page = mapSpeaker(e.synth);
  const pending = page.run({ title: '沿通道前行', detail: '前往升降機' });
  expect(page.narrationStatus.textContent).toBe('正在載入粵語聲音…');
  await vi.advanceTimersByTimeAsync(320);
  e.update([female]);
  await pending;
  expect(e.play).toHaveBeenCalledTimes(1);
  expect(page.narrationStatus.textContent).toBe('語音提示已完成。');
});
it('map-demo: only the latest request speaks after delayed loading', async () => {
  const e = engine();
  const page = mapSpeaker(e.synth);
  const first = page.run({ title: '舊步驟', detail: '' });
  const second = page.run({ title: '新步驟', detail: '' });
  e.update([female]);
  await Promise.all([first, second]);
  expect(e.play.mock.calls.map(([u]) => u.text)).toEqual(['新步驟。']);
  expect(vi.getTimerCount()).toBe(0);
});
it('map-demo: leaving the page cancels a pending voice load', async () => {
  const e = engine();
  const page = mapSpeaker(e.synth);
  const pending = page.run({ title: '舊步驟', detail: '' });
  page.hide();
  e.update([female]);
  await pending;
  expect(e.play).not.toHaveBeenCalled();
  expect(e.listeners.size).toBe(0);
  expect(vi.getTimerCount()).toBe(0);
});
