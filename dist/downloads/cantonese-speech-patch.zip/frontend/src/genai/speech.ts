import type { SpeechPlan } from '../../../shared/genai/workflows';

// Wait for Cantonese specifically: some browsers expose English voices first.
export function loadCantoneseVoices(
  synth: SpeechSynthesis,
  signal?: AbortSignal,
): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve, reject) => {
    let timeout: ReturnType<typeof setTimeout>;
    let poll: ReturnType<typeof setInterval>;
    const cleanup = () => {
      clearTimeout(timeout);
      clearInterval(poll);
      synth.removeEventListener?.('voiceschanged', check);
      signal?.removeEventListener('abort', abort);
    };
    const finish = (voices: SpeechSynthesisVoice[]) => {
      cleanup();
      resolve(voices);
    };
    const abort = () => {
      cleanup();
      reject(new DOMException('Speech request superseded', 'AbortError'));
    };
    const check = () => {
      if (signal?.aborted) return abort();
      try {
        const voices = synth
          .getVoices()
          .filter((voice) => /^(?:zh-HK|yue)(?:-|$)/i.test(voice.lang.replace(/_/g, '-')));
        if (voices.length) finish(voices);
      } catch (error) {
        cleanup();
        reject(error);
      }
    };
    synth.addEventListener?.('voiceschanged', check);
    signal?.addEventListener('abort', abort, { once: true });
    timeout = setTimeout(() => finish([]), 5000);
    // Also handle engines that update their list without firing voiceschanged.
    poll = setInterval(check, 100);
    check();
  });
}

let pendingVoiceLoad: AbortController | undefined;

export async function speak(text: string, plan: SpeechPlan): Promise<void> {
  if (plan.selection === 'text_only') return;
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined')
    throw new Error('此瀏覽器未提供語音播報');
  const synth = window.speechSynthesis;
  pendingVoiceLoad?.abort();
  const controller = new AbortController();
  pendingVoiceLoad = controller;
  synth.cancel();
  let cantonese: SpeechSynthesisVoice[];
  try {
    cantonese = await loadCantoneseVoices(synth, controller.signal);
  } catch (error) {
    if (controller.signal.aborted) return;
    throw error;
  } finally {
    if (pendingVoiceLoad === controller) pendingVoiceLoad = undefined;
  }
  if (controller.signal.aborted) return;
  if (!cantonese.length)
    throw new Error('等候後瀏覽器仍未提供粵語語音；請檢查系統語音設定，或使用文字指引');
  return new Promise((resolve, reject) => {
    const preferred =
      plan.selection === 'cantonese_male'
        ? /(?<!fe)male|wanlung|danny|男/i
        : /female|sinji|hiumaan|女/i;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = cantonese.find((v) => preferred.test(v.name)) || cantonese[0];
    utterance.lang = utterance.voice.lang;
    utterance.rate = 0.9;
    utterance.onend = () => resolve();
    utterance.onerror = (e) => reject(new Error(`語音播放失敗：${e.error}`));
    synth.speak(utterance);
  });
}
